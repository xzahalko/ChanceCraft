## Description

* This mod allows you to setup probability of crafting armor, weapons and ammo.
* With Failiour craft you loose your resources, only one resource at random is given back.
* WHen try to upgrade item fails you loose only one resource from recipe.

## Join me on discord to report bugs and give me feedback:

Link: <a href="https://discord.gg/rKGzYaH4">https://discord.gg/rKGzYaH4</a>

## Release notes:

### v1.1.2
* Inicitial release
* Set probability separately for armor, weapons annd ammo
