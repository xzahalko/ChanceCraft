## Description

* This mod allows you to setup probability of crafting armor, weapons and ammo.
* With Failiour craft you loose your resources, only one resource at random is given back.
* When try to upgrade item fails you loose only one resource from recipe.
* On any problems contact me on discord.

## Join me on discord to report bugs and give me feedback:

Link: <a href="https://discord.gg/rKGzYaH4">https://discord.gg/rKGzYaH4</a>

## Release notes:

### v1.1.5
* Added possibility to add 5 items prefabs with percentages.
* Theese items if in inventory while crafting will be consumed and will increase craft success percentage.

### v1.1.4
* Revision of structure, separation of helpers in separate files.

### v1.1.3
* Added possibility to set percentage for upgrading separatelly

### v1.1.2
* Inicitial release
* Set probability separately for armor, weapons annd ammo
